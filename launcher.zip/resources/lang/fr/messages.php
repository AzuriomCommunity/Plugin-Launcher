<?php
return [
    "description" => "Sur cette page, vous pouvez télécharger un launcher pour notre serveur Minecraft.",
    "title" => "Launcher"
];
