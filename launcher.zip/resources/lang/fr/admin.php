<?php
return [
    "os" => ["linux" => "Linux", "mac" => "MAC", "windows" => "Windows"],
    "title" => "Launcher"
];
