<?php
return [
    "description" => "In this page you can download a launcher for our minecraft server.",
    "title" => "Launcher"
];
