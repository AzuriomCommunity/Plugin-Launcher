<?php
return [
    "os" => ["linux" => "Linux", "mac" => "Mac", "windows" => "Windows"],
    "title" => "Launcher"
];
